package net.earthcomputer.clientcommands.interfaces;

// marker interface for creative slots
public interface ICreativeSlot {
}
