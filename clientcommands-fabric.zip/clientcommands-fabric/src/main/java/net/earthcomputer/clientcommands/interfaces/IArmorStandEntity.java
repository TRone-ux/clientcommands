package net.earthcomputer.clientcommands.interfaces;

public interface IArmorStandEntity {

    boolean isArmorStandInvisible();

}
