package net.earthcomputer.clientcommands.interfaces;

public interface ITextFieldWidget {

    int clientcommands_getMaxLength();

}
