package net.earthcomputer.clientcommands.interfaces;

import net.minecraft.inventory.Inventory;

public interface IDroppableInventoryContainer {

    Inventory getDroppableInventory();

}
