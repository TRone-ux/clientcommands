package net.earthcomputer.clientcommands.interfaces;

import net.minecraft.screen.ScreenHandlerContext;

public interface IEnchantingTableContainer {

    ScreenHandlerContext getContext();

}
